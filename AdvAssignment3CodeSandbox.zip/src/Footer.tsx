import React from "react";

function Footer() {
  return (
    <div>
      <h6> @2024 Christopher H.</h6>
    </div>
  );
}

export default Footer;
