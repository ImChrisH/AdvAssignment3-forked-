import React from "react";

function Header() {
  return (
    <div className="hWrap">
      <h1 className="empH">Employees of the month!</h1>
    </div>
  );
}

export default Header;
